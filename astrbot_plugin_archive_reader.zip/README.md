# 压缩包阅读插件 (astrbot_plugin_archive_reader)

让 AstrBot 阅读压缩包内容的插件。支持查看目录结构、AI 分析用途、提取文件原文。

## 支持格式

- `.zip` / `.7z` / `.rar`（rar 需系统安装 unrar）
- `.tar` / `.tar.gz` / `.tgz` / `.tar.bz2` / `.tbz2` / `.tar.xz` / `.txz`
- `.gz` / `.bz2` / `.xz`（单文件压缩）

## 使用方法

### 群聊

1. 发送压缩包到群里
2. **@机器人** 并 **引用/回复** 那条压缩包消息
3. 提问：
   - **问结构**：「结构」「目录」「有什么文件」→ 返回目录树
   - **问作用**：「这个是干嘛的」「什么项目」「分析一下」→ AI 阅读文件后分析
   - **问原文**：「index.html 原文」「读一下 package.json」→ 发送该文件的 txt 版本

也可以在发送压缩包并 @机器人 的同一条消息里直接提问。

### 私聊

1. 直接发送压缩包，机器人回复「收到」
2. 然后直接提问即可，30 分钟内有效

## 安装

1. 将 `astrbot_plugin_archive_reader` 文件夹放到 AstrBot 的 `data/plugins/` 目录下
2. 安装依赖：
   ```bash
   pip install -r data/plugins/astrbot_plugin_archive_reader/requirements.txt
   ```
3. 重启 AstrBot 或在 WebUI 重载插件

### RAR 格式支持（可选）

如需支持 .rar 文件，还需在系统安装 unrar：

```bash
# Ubuntu/Debian
sudo apt install unrar

# CentOS/RHEL
sudo yum install unrar

# macOS
brew install unrar
```

## 问题排查

### 群聊提示"群文件权限不够"

**本插件不会出现此问题。** 此问题的原因是旧插件调用了 `get_group_root_files` / `get_group_files_by_folder` 等群文件管理接口（需要管理员权限）。本插件直接使用 AstrBot 框架已自动获取的文件下载链接（`get_group_file_url`），该接口任何群成员都可使用，不需要特殊权限。

如果仍然遇到下载失败：
1. 确认 NapCat 版本为最新版
2. 检查 NapCat 日志是否有报错
3. 确认机器人在群内且文件未过期

### 私聊问"xx文件是什么"回答"未收到文件"

**本插件已解决此问题。** 插件会按会话（群/私聊）记住最近发送的压缩包，后续提问直接从已解压的文件中查找。同时通过 `on_llm_request` 钩子向 AI 注入压缩包上下文，即使问题没有被插件直接识别，AI 也能知道压缩包的存在。

### 发送文件失败（Docker 环境）

如果 AstrBot 和 NapCat 运行在不同的 Docker 容器中，NapCat 可能无法读取 AstrBot 生成的文件路径。解决方案：

1. **推荐**：在 AstrBot 配置中设置 `callback_api_base`（WebUI → 配置 → 网络设置），让 AstrBot 通过 HTTP 提供文件
2. 或者将 AstrBot 和 NapCat 的数据目录挂载到同一个共享卷

### 加密压缩包

暂不支持加密/带密码的压缩包，请先解压后重新打包发送。

## 安全措施

- 解压时自动检测并阻止路径穿越攻击（`../`）
- 限制解压总大小（100MB）和文件数量（500个）
- 限制单个文件读取大小（2MB）
- 自动识别二进制文件（exe/图片/视频等），不尝试读取
- 会话 30 分钟自动过期清理临时文件
