"""
AstrBot 压缩包阅读插件
支持 zip/rar/7z/tar/gz/bz2/xz 等格式
群聊：艾特机器人并引用压缩包消息，提问结构/作用/文件原文
私聊：发送压缩包后回复"收到"，等待后续提问
"""

from __future__ import annotations

import os
import re
import gzip
import bz2
import lzma
import shutil
import zipfile
import tarfile
import tempfile
import time
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

import aiofiles
import aiohttp

from astrbot.api import logger
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Context, Star, StarTools
import astrbot.api.message_components as Comp
from astrbot.api.message_components import File, Plain, Reply
from astrbot.core.agent.message import TextPart

# 可选依赖
try:
    import py7zr
    HAS_7Z = True
except ImportError:
    HAS_7Z = False

try:
    import rarfile
    HAS_RAR = True
except ImportError:
    HAS_RAR = False

try:
    import chardet
    HAS_CHARDET = True
except ImportError:
    HAS_CHARDET = False


# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

# 支持的压缩包扩展名
ARCHIVE_EXTS = (
    ".zip", ".rar", ".7z",
    ".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz",
    ".gz", ".bz2", ".xz",
)

# 可读取为文本的扩展名
TEXT_EXTS = {
    # 代码
    ".py", ".js", ".ts", ".jsx", ".tsx", ".vue", ".svelte",
    ".java", ".c", ".cpp", ".cc", ".cxx", ".h", ".hpp", ".hh",
    ".cs", ".go", ".rs", ".rb", ".php", ".swift", ".kt", ".kts",
    ".scala", ".sh", ".bash", ".zsh", ".fish", ".bat", ".cmd", ".ps1",
    ".sql", ".lua", ".pl", ".pm", ".r", ".m", ".mm", ".dart",
    ".gradle", ".groovy", ".clj", ".cljs", ".ex", ".exs", ".erl",
    ".hs", ".ml", ".elm", ".zig", ".nim", ".v", ".cr",
    # Web
    ".html", ".htm", ".xhtml", ".shtml", ".css", ".scss", ".sass", ".less",
    # 数据/配置
    ".json", ".json5", ".jsonc", ".xml", ".yaml", ".yml", ".toml",
    ".ini", ".cfg", ".conf", ".config", ".properties", ".prop",
    ".env", ".gitignore", ".dockerignore", ".editorconfig",
    ".csv", ".tsv", ".psv",
    # 文档
    ".txt", ".md", ".rst", ".log", ".tex", ".bib", ".org",
    ".makefile", ".cmake", ".dockerfile", ".vagrantfile",
    # 脚本/其他
    ".svg", ".graphql", ".gql", ".proto", ".thrift",
    ".diff", ".patch", ".map", ".lock",
    ".wxml", ".wxss", ".axml", ".acss", ".swan",
    ".qml", ".pro", ".pri",
}

# 明确跳过的二进制扩展名
BINARY_EXTS = {
    ".exe", ".dll", ".so", ".dylib", ".bin", ".msi", ".app", ".deb", ".rpm",
    ".apk", ".ipa", ".class", ".jar", ".war", ".pyc", ".pyo", ".o", ".a",
    ".lib", ".obj", ".wasm", ".elf",
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".ico", ".webp", ".tiff",
    ".psd", ".ai", ".eps", ".raw", ".cr2", ".nef",
    ".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma", ".m4a", ".amr",
    ".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm", ".m4v",
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz",
    ".dat", ".db", ".sqlite", ".sqlite3", ".mdb",
    ".ttf", ".otf", ".woff", ".woff2", ".eot",
    ".swf", ".class",
}

# 单文件解压的最大大小 (50MB)
MAX_ARCHIVE_SIZE = 50 * 1024 * 1024
# 解压后总大小上限 (100MB)
MAX_EXTRACTED_SIZE = 100 * 1024 * 1024
# 解压后文件数上限
MAX_FILE_COUNT = 500
# 单个文件读取上限 (2MB)
MAX_FILE_READ_SIZE = 2 * 1024 * 1024
# LLM 分析时每个文件的内容上限 (8KB)
LLM_FILE_CONTENT_LIMIT = 8 * 1024
# LLM 分析总内容上限 (60KB)
LLM_TOTAL_CONTENT_LIMIT = 60 * 1024
# 会话过期时间 (秒)
SESSION_EXPIRE = 1800  # 30 分钟

# 文件名匹配正则（从用户提问中提取文件名）
FILENAME_PATTERN = re.compile(
    r'[A-Za-z0-9_\-./\\]+\.(?:' +
    '|'.join(e.lstrip('.') for e in sorted(TEXT_EXTS, key=len, reverse=True)) +
    r')',
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# 数据结构
# ---------------------------------------------------------------------------

@dataclass
class ArchiveSession:
    """一个会话中已解压的压缩包状态"""
    original_name: str          # 原始压缩包文件名
    extract_dir: str            # 解压目录
    file_list: list[str] = field(default_factory=list)  # 相对路径列表
    file_tree: str = ""         # 目录树文本
    created_at: float = 0.0     # 创建时间
    last_used: float = 0.0      # 最后使用时间
    total_size: int = 0         # 解压后总大小


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------

def is_archive(filename: str) -> bool:
    """判断文件名是否为支持的压缩包格式"""
    name = filename.lower()
    return any(name.endswith(ext) for ext in ARCHIVE_EXTS)


def is_text_file(filename: str) -> bool:
    """根据扩展名判断是否可能是文本文件"""
    name = filename.lower()
    # 无扩展名文件也可能是文本（如 Dockerfile, Makefile, LICENSE）
    ext = Path(name).suffix
    if ext in BINARY_EXTS:
        return False
    if ext in TEXT_EXTS:
        return True
    # 无扩展名：检查常见文件名
    basename = Path(name).name
    if basename in {
        "dockerfile", "makefile", "rakefile", "gemfile", "license",
        "readme", "changelog", "authors", "contributors", "todo",
        "vagrantfile", "berksfile", "pipfile", "procfile",
        ".gitignore", ".dockerignore", ".editorconfig", ".env",
        "cmakelists.txt",  # .txt 已覆盖
    }:
        return True
    return False


def detect_archive_type(filename: str) -> str:
    """检测压缩包类型"""
    name = filename.lower()
    if name.endswith(".zip"):
        return "zip"
    if name.endswith(".rar"):
        return "rar"
    if name.endswith(".7z"):
        return "7z"
    if name.endswith((".tar.gz", ".tgz")):
        return "tar.gz"
    if name.endswith((".tar.bz2", ".tbz2")):
        return "tar.bz2"
    if name.endswith((".tar.xz", ".txz")):
        return "tar.xz"
    if name.endswith(".tar"):
        return "tar"
    if name.endswith(".gz"):
        return "gz"
    if name.endswith(".bz2"):
        return "bz2"
    if name.endswith(".xz"):
        return "xz"
    return "unknown"


def safe_read_text(file_path: str, max_size: int = MAX_FILE_READ_SIZE) -> str:
    """安全读取文本文件，自动检测编码"""
    try:
        size = os.path.getsize(file_path)
        if size > max_size:
            return f"[文件过大: {size} 字节，超过 {max_size} 字节限制]"
        with open(file_path, "rb") as f:
            raw = f.read(max_size)
        if not raw:
            return "[空文件]"
        # 先尝试常见编码
        for enc in ("utf-8", "utf-8-sig", "gbk", "gb2312", "gb18030",
                     "big5", "shift_jis", "euc-kr", "latin-1"):
            try:
                return raw.decode(enc)
            except (UnicodeDecodeError, LookupError):
                continue
        # chardet 检测
        if HAS_CHARDET:
            result = chardet.detect(raw)
            if result and result.get("encoding"):
                try:
                    return raw.decode(result["encoding"])
                except (UnicodeDecodeError, LookupError):
                    pass
        return "[无法识别文件编码，可能是二进制文件]"
    except Exception as e:
        return f"[读取失败: {e}]"


def build_file_tree(file_list: list[str]) -> str:
    """根据文件列表构建目录树"""
    # 构建目录结构
    tree: dict = {}
    for fpath in sorted(file_list):
        parts = fpath.replace("\\", "/").split("/")
        node = tree
        for part in parts:
            node = node.setdefault(part, {})

    lines: list[str] = []

    def _render(node: dict, prefix: str = ""):
        items = sorted(node.items())
        for i, (name, children) in enumerate(items):
            is_last = i == len(items) - 1
            connector = "└── " if is_last else "├── "
            if children:
                lines.append(f"{prefix}{connector}{name}/")
                _render(children, prefix + ("    " if is_last else "│   "))
            else:
                lines.append(f"{prefix}{connector}{name}")

    _render(tree)
    return "\n".join(lines)


def _is_within_directory(directory: str, target: str) -> bool:
    """检查目标路径是否在目录内（防路径穿越）"""
    abs_directory = os.path.abspath(directory)
    abs_target = os.path.abspath(target)
    prefix = os.path.commonprefix([abs_directory, abs_target])
    return prefix == abs_directory


def _safe_extract_zip(zf: zipfile.ZipFile, path: str) -> list[str]:
    """安全解压 zip"""
    members = zf.namelist()
    extracted: list[str] = []
    total = 0
    for member in members:
        member_path = os.path.join(path, member)
        if not _is_within_directory(path, member_path):
            logger.warning(f"跳过可疑路径（防穿越）: {member}")
            continue
        if member.endswith("/"):
            os.makedirs(member_path, exist_ok=True)
            continue
        os.makedirs(os.path.dirname(member_path), exist_ok=True)
        # 检查大小
        info = zf.getinfo(member)
        total += info.file_size
        if total > MAX_EXTRACTED_SIZE:
            raise ValueError(f"解压后总大小超过 {MAX_EXTRACTED_SIZE // 1024 // 1024}MB 限制")
        if len(extracted) >= MAX_FILE_COUNT:
            raise ValueError(f"文件数量超过 {MAX_FILE_COUNT} 限制")
        with zf.open(member) as src, open(member_path, "wb") as dst:
            shutil.copyfileobj(src, dst)
        extracted.append(member)
    return extracted


def _safe_extract_tar(tf: tarfile.TarFile, path: str) -> list[str]:
    """安全解压 tar"""
    members = tf.getmembers()
    extracted: list[str] = []
    total = 0
    for member in members:
        member_path = os.path.join(path, member.name)
        if not _is_within_directory(path, member_path):
            logger.warning(f"跳过可疑路径（防穿越）: {member.name}")
            continue
        if member.isdir():
            os.makedirs(member_path, exist_ok=True)
            continue
        if not member.isfile():
            continue
        total += member.size
        if total > MAX_EXTRACTED_SIZE:
            raise ValueError(f"解压后总大小超过 {MAX_EXTRACTED_SIZE // 1024 // 1024}MB 限制")
        if len(extracted) >= MAX_FILE_COUNT:
            raise ValueError(f"文件数量超过 {MAX_FILE_COUNT} 限制")
        os.makedirs(os.path.dirname(member_path), exist_ok=True)
        tf.extract(member, path)
        extracted.append(member.name)
    return extracted


# ---------------------------------------------------------------------------
# 主插件类
# ---------------------------------------------------------------------------

class ArchiveReaderPlugin(Star):
    def __init__(self, context: Context):
        super().__init__(context)
        self.data_dir = str(StarTools.get_data_dir("astrbot_plugin_archive_reader"))
        os.makedirs(self.data_dir, exist_ok=True)
        # 会话状态: unified_msg_origin -> ArchiveSession
        self.sessions: dict[str, ArchiveSession] = {}
        logger.info("[ArchiveReader] 压缩包阅读插件已加载")

    async def terminate(self):
        """插件卸载时清理"""
        self._cleanup_all_sessions()

    # ------------------------------------------------------------------
    # 会话管理
    # ------------------------------------------------------------------

    def _cleanup_all_sessions(self):
        """清理所有会话的临时文件"""
        for session in self.sessions.values():
            try:
                if os.path.exists(session.extract_dir):
                    shutil.rmtree(session.extract_dir, ignore_errors=True)
            except Exception:
                pass
        self.sessions.clear()

    def _cleanup_expired(self):
        """清理过期会话"""
        now = time.time()
        expired = [
            uid for uid, s in self.sessions.items()
            if now - s.last_used > SESSION_EXPIRE
        ]
        for uid in expired:
            s = self.sessions.pop(uid)
            try:
                if os.path.exists(s.extract_dir):
                    shutil.rmtree(s.extract_dir, ignore_errors=True)
            except Exception:
                pass
            logger.info(f"[ArchiveReader] 清理过期会话: {uid}")

    def _get_session(self, umo: str) -> Optional[ArchiveSession]:
        """获取有效会话"""
        self._cleanup_expired()
        s = self.sessions.get(umo)
        if s:
            s.last_used = time.time()
        return s

    def _set_session(self, umo: str, session: ArchiveSession):
        """设置会话（会清理旧会话）"""
        old = self.sessions.pop(umo, None)
        if old and os.path.exists(old.extract_dir):
            try:
                shutil.rmtree(old.extract_dir, ignore_errors=True)
            except Exception:
                pass
        self.sessions[umo] = session

    # ------------------------------------------------------------------
    # 文件查找
    # ------------------------------------------------------------------

    @staticmethod
    def _find_file_component(event: AstrMessageEvent) -> Optional[File]:
        """从当前消息或引用消息中查找 File 组件"""
        # 1. 当前消息链中查找
        for comp in event.message_obj.message:
            if isinstance(comp, File):
                return comp
        # 2. 引用消息中查找
        for comp in event.message_obj.message:
            if isinstance(comp, Reply):
                for sub in comp.chain:
                    if isinstance(sub, File):
                        return sub
        return None

    @staticmethod
    def _get_file_name_from_raw(event: AstrMessageEvent) -> Optional[str]:
        """从原始消息中尝试获取文件名（备用）"""
        try:
            raw = event.message_obj.raw_message
            if not raw:
                return None
            # raw 可能是 dict 或 pydantic 模型
            msg = None
            if isinstance(raw, dict):
                msg = raw.get("message", [])
            elif hasattr(raw, "get"):
                msg = raw.get("message", [])
            elif hasattr(raw, "message"):
                msg = raw.message
            if not isinstance(msg, list):
                return None
            for seg in msg:
                if isinstance(seg, dict) and seg.get("type") == "file":
                    data = seg.get("data", {})
                    return data.get("file_name") or data.get("name")
        except Exception:
            pass
        return None

    async def _download_file(self, file_comp: File, event: AstrMessageEvent) -> Optional[str]:
        """下载文件到本地，返回本地路径"""
        # 优先使用 File 组件自带的下载能力
        try:
            path = await file_comp.get_file()
            if path and os.path.exists(path):
                return path
        except Exception as e:
            logger.warning(f"[ArchiveReader] File.get_file() 失败: {e}")

        # 备用：如果有 URL，自行下载
        if file_comp.url:
            try:
                tmp_dir = os.path.join(self.data_dir, "downloads")
                os.makedirs(tmp_dir, exist_ok=True)
                safe_name = re.sub(r'[^\w\-.]', '_', file_comp.name or "archive")
                local_path = os.path.join(tmp_dir, f"{int(time.time())}_{safe_name}")
                async with aiohttp.ClientSession() as session:
                    async with session.get(file_comp.url, timeout=aiohttp.ClientTimeout(total=120)) as resp:
                        if resp.status == 200:
                            async with aiofiles.open(local_path, "wb") as f:
                                await f.write(await resp.read())
                            return local_path
            except Exception as e:
                logger.warning(f"[ArchiveReader] URL 下载失败: {e}")

        # 最后备用：通过 raw_message 中的 file_id 调用 NapCat API
        try:
            return await self._download_via_napcat(event, file_comp)
        except Exception as e:
            logger.error(f"[ArchiveReader] NapCat API 下载失败: {e}")

        return None

    async def _download_via_napcat(self, event: AstrMessageEvent, file_comp: File) -> Optional[str]:
        """通过 NapCat API 下载文件（最后备用方案）"""
        try:
            # 兼容不同版本的 aiocqhttp 事件类
            client = getattr(event, "bot", None)
            if client is None:
                return None

            raw = event.message_obj.raw_message
            if not raw:
                return None

            # call_action 兼容：新版 aiocqhttp 用 client.call_action，
            # 部分版本用 client.api.call_action
            async def _call_action(action: str, **kwargs):
                if hasattr(client, "call_action"):
                    return await client.call_action(action, **kwargs)
                elif hasattr(client, "api") and hasattr(client.api, "call_action"):
                    return await client.api.call_action(action, **kwargs)
                raise RuntimeError("无法调用 OneBot API: 未找到 call_action 方法")

            # 从原始消息中提取 file_id
            file_id = None
            msg = raw.get("message", [])
            if isinstance(msg, list):
                for seg in msg:
                    if seg.get("type") == "file":
                        file_id = seg.get("data", {}).get("file_id")
                        break

            # 如果当前消息没有，检查引用消息
            if not file_id:
                for comp in event.message_obj.message:
                    if isinstance(comp, Reply):
                        try:
                            reply_data = await _call_action(
                                "get_msg", message_id=int(comp.id)
                            )
                            for seg in reply_data.get("message", []):
                                if seg.get("type") == "file":
                                    file_id = seg.get("data", {}).get("file_id")
                                    break
                        except Exception:
                            pass

            if not file_id:
                return None

            # 群聊用 get_group_file_url，私聊用 get_private_file_url
            is_group = event.get_group_id()
            if is_group:
                ret = await _call_action(
                    "get_group_file_url",
                    file_id=file_id,
                    group_id=int(is_group),
                )
            else:
                ret = await _call_action(
                    "get_private_file_url",
                    file_id=file_id,
                )

            if not ret or "url" not in ret:
                logger.error(f"[ArchiveReader] 获取文件URL失败: {ret}")
                return None

            # 下载
            tmp_dir = os.path.join(self.data_dir, "downloads")
            os.makedirs(tmp_dir, exist_ok=True)
            safe_name = re.sub(r'[^\w\-.]', '_', file_comp.name or "archive")
            local_path = os.path.join(tmp_dir, f"{int(time.time())}_{safe_name}")
            async with aiohttp.ClientSession() as session:
                async with session.get(ret["url"], timeout=aiohttp.ClientTimeout(total=120)) as resp:
                    if resp.status == 200:
                        async with aiofiles.open(local_path, "wb") as f:
                            await f.write(await resp.read())
                        return local_path
        except Exception as e:
            logger.error(f"[ArchiveReader] NapCat 下载异常: {e}")
        return None

    # ------------------------------------------------------------------
    # 解压
    # ------------------------------------------------------------------

    async def extract_archive(self, file_path: str, original_name: str) -> tuple[str, list[str]]:
        """解压压缩包，返回 (解压目录, 文件列表)"""
        extract_dir = tempfile.mkdtemp(prefix="archive_", dir=self.data_dir)
        arch_type = detect_archive_type(original_name)
        file_list: list[str] = []

        logger.info(f"[ArchiveReader] 开始解压: {original_name} (类型: {arch_type})")

        try:
            if arch_type == "zip":
                with zipfile.ZipFile(file_path, "r") as zf:
                    # 检查加密
                    for info in zf.infolist():
                        if info.flag_bits & 0x1:
                            raise ValueError("加密的 ZIP 文件暂不支持")
                    file_list = _safe_extract_zip(zf, extract_dir)

            elif arch_type in ("tar", "tar.gz", "tar.bz2", "tar.xz"):
                mode_map = {
                    "tar": "r:",
                    "tar.gz": "r:gz",
                    "tar.bz2": "r:bz2",
                    "tar.xz": "r:xz",
                }
                with tarfile.open(file_path, mode_map[arch_type]) as tf:
                    file_list = _safe_extract_tar(tf, extract_dir)

            elif arch_type == "7z":
                if not HAS_7Z:
                    raise ValueError("7z 格式需要安装 py7zr 库，请在插件目录执行 pip install py7zr")
                with py7zr.SevenZipFile(file_path, mode="r") as z:
                    if z.needs_password():
                        raise ValueError("加密的 7z 文件暂不支持")
                    z.extractall(path=extract_dir)
                # 收集文件列表
                for root, dirs, files in os.walk(extract_dir):
                    for f in files:
                        full = os.path.join(root, f)
                        rel = os.path.relpath(full, extract_dir)
                        file_list.append(rel)

            elif arch_type == "rar":
                if not HAS_RAR:
                    raise ValueError("RAR 格式需要安装 rarfile 库和 unrar 工具")
                with rarfile.RarFile(file_path) as rf:
                    if rf.needs_password():
                        raise ValueError("加密的 RAR 文件暂不支持")
                    for info in rf.infolist():
                        if info.isdir():
                            continue
                        member_path = os.path.join(extract_dir, info.filename)
                        if not _is_within_directory(extract_dir, member_path):
                            continue
                        os.makedirs(os.path.dirname(member_path), exist_ok=True)
                        rf.extract(info, extract_dir)
                        file_list.append(info.filename)

            elif arch_type == "gz":
                # 单文件 gzip
                out_name = original_name[:-3] if original_name.lower().endswith(".gz") else "output"
                out_path = os.path.join(extract_dir, out_name)
                with gzip.open(file_path, "rb") as f_in:
                    with open(out_path, "wb") as f_out:
                        shutil.copyfileobj(f_in, f_out)
                file_list.append(out_name)

            elif arch_type == "bz2":
                out_name = original_name[:-4] if original_name.lower().endswith(".bz2") else "output"
                out_path = os.path.join(extract_dir, out_name)
                with bz2.open(file_path, "rb") as f_in:
                    with open(out_path, "wb") as f_out:
                        shutil.copyfileobj(f_in, f_out)
                file_list.append(out_name)

            elif arch_type == "xz":
                out_name = original_name[:-3] if original_name.lower().endswith(".xz") else "output"
                out_path = os.path.join(extract_dir, out_name)
                with lzma.open(file_path, "rb") as f_in:
                    with open(out_path, "wb") as f_out:
                        shutil.copyfileobj(f_in, f_out)
                file_list.append(out_name)

            else:
                raise ValueError(f"不支持的压缩包格式: {original_name}")

        except Exception:
            # 解压失败时清理
            shutil.rmtree(extract_dir, ignore_errors=True)
            raise

        # 计算总大小
        total_size = 0
        for f in file_list:
            fp = os.path.join(extract_dir, f)
            if os.path.isfile(fp):
                total_size += os.path.getsize(fp)

        logger.info(f"[ArchiveReader] 解压完成: {len(file_list)} 个文件, {total_size} 字节")
        return extract_dir, file_list

    # ------------------------------------------------------------------
    # 意图识别
    # ------------------------------------------------------------------

    @staticmethod
    def _detect_intent(text: str) -> tuple[str, Optional[str]]:
        """识别用户意图，返回 (intent, target_file)
        intent: structure / purpose / content / file_purpose / unknown
        """
        t = text.lower().strip()

        # 提取可能的文件名
        filename_match = FILENAME_PATTERN.search(text)
        target_file = filename_match.group(0) if filename_match else None

        # 文件原文意图
        content_keywords = ["原文", "内容是", "读一下", "读取", "发给我", "发送给我",
                           "给我看", "看一下内容", "输出", "提取", "导出", "txt",
                           "文本", "源代码", "源码内容"]
        if target_file and any(k in t for k in content_keywords):
            return "content", target_file
        # "xx文件原文" / "xx的内容"
        if target_file and ("原文" in t or "内容" in t):
            return "content", target_file

        # 单个文件作用意图
        purpose_keywords = ["是干嘛", "是干什", "有什么用", "什么作用", "什么意思",
                           "怎么用", "解释", "说明一下", "介绍一下", "分析一下"]
        if target_file and any(k in t for k in purpose_keywords):
            return "file_purpose", target_file
        # "xx是什么" / "xx是什么文件"
        if target_file and ("是什么" in t or "干嘛" in t):
            return "file_purpose", target_file

        # 结构意图
        structure_keywords = ["结构", "目录", "有什么文件", "有哪些文件", "都有什么",
                             "文件列表", "列出", "文件树", "目录树", "里面有什么",
                             "都有啥", "有啥文件", "打包了什么"]
        if any(k in t for k in structure_keywords):
            return "structure", None

        # 整体作用意图
        whole_purpose_keywords = ["什么用", "干嘛的", "干什么", "是什么东西",
                                 "什么项目", "什么游戏", "什么软件", "什么程序",
                                 "什么代码", "什么网站", "什么网页", "什么系统",
                                 "有什么功能", "主要功能", "介绍", "分析", "说明",
                                 "这个压缩包", "这个包是", "这个文件是"]
        if any(k in t for k in whole_purpose_keywords):
            return "purpose", None

        # 如果提到了文件名但没有明确意图，默认问内容
        if target_file:
            return "content", target_file

        return "unknown", None

    # ------------------------------------------------------------------
    # 处理逻辑
    # ------------------------------------------------------------------

    async def _process_archive(
        self, event: AstrMessageEvent, file_comp: File
    ) -> Optional[ArchiveSession]:
        """下载并解压压缩包，创建会话"""
        file_name = file_comp.name or "archive"
        if not is_archive(file_name):
            # 尝试从 raw message 获取
            raw_name = self._get_file_name_from_raw(event)
            if raw_name:
                file_name = raw_name
            if not is_archive(file_name):
                await event.send(event.plain_result(
                    f"文件 {file_name} 不是支持的压缩包格式。\n"
                    f"支持的格式: zip, rar, 7z, tar, tar.gz, gz, bz2, xz"
                ))
                return None

        await event.send(event.plain_result(f"正在下载并解压 {file_name}，请稍候..."))

        # 下载
        local_path = await self._download_file(file_comp, event)
        if not local_path or not os.path.exists(local_path):
            await event.send(event.plain_result(
                "文件下载失败。可能原因：\n"
                "1. NapCat 与 AstrBot 网络不通\n"
                "2. 文件链接已过期\n"
                "请检查 NapCat 日志或重新发送文件。"
            ))
            return None

        # 检查文件大小
        file_size = os.path.getsize(local_path)
        if file_size > MAX_ARCHIVE_SIZE:
            await event.send(event.plain_result(
                f"文件过大（{file_size // 1024 // 1024}MB），超过 {MAX_ARCHIVE_SIZE // 1024 // 1024}MB 限制。"
            ))
            return None

        # 解压
        try:
            extract_dir, file_list = await self.extract_archive(local_path, file_name)
        except zipfile.BadZipFile:
            await event.send(event.plain_result("文件不是有效的 ZIP 压缩包，可能已损坏。"))
            return None
        except tarfile.ReadError:
            await event.send(event.plain_result("文件不是有效的 tar 压缩包，可能已损坏。"))
            return None
        except ValueError as e:
            await event.send(event.plain_result(f"解压失败: {e}"))
            return None
        except Exception as e:
            logger.exception(f"[ArchiveReader] 解压异常: {e}")
            await event.send(event.plain_result(f"解压失败: {e}"))
            return None
        finally:
            # 清理下载的原始文件（如果在我们的 downloads 目录）
            if "downloads" in local_path:
                try:
                    os.remove(local_path)
                except Exception:
                    pass

        if not file_list:
            await event.send(event.plain_result("压缩包为空或无法读取其中的文件。"))
            return None

        # 构建目录树
        tree = build_file_tree(file_list)

        session = ArchiveSession(
            original_name=file_name,
            extract_dir=extract_dir,
            file_list=file_list,
            file_tree=tree,
            created_at=time.time(),
            last_used=time.time(),
        )
        self._set_session(event.unified_msg_origin, session)
        return session

    def _find_file_in_archive(self, session: ArchiveSession, target: str) -> Optional[str]:
        """在压缩包中查找文件，支持模糊匹配"""
        target = target.replace("\\", "/").lower()
        target_basename = Path(target).name.lower()

        # 精确匹配完整路径
        for f in session.file_list:
            if f.replace("\\", "/").lower() == target:
                return f

        # 匹配 basename
        basename_matches = [
            f for f in session.file_list
            if Path(f.replace("\\", "/")).name.lower() == target_basename
        ]
        if len(basename_matches) == 1:
            return basename_matches[0]
        if len(basename_matches) > 1:
            # 多个匹配，尝试路径包含匹配
            path_matches = [
                f for f in basename_matches
                if target in f.replace("\\", "/").lower()
            ]
            if len(path_matches) == 1:
                return path_matches[0]
            # 返回第一个并提示
            return basename_matches[0]

        # 模糊包含匹配
        contains = [
            f for f in session.file_list
            if target_basename in Path(f.replace("\\", "/")).name.lower()
        ]
        if len(contains) == 1:
            return contains[0]

        return None

    async def _handle_structure(self, event: AstrMessageEvent, session: ArchiveSession):
        """处理结构查询"""
        tree = session.file_tree
        msg = f"压缩包 {session.original_name} 的目录结构（共 {len(session.file_list)} 个文件）：\n\n{tree}"
        if len(msg) > 4000:
            msg = msg[:3900] + "\n...（内容过长，已截断）"
        yield event.plain_result(msg)

    async def _handle_purpose(self, event: AstrMessageEvent, session: ArchiveSession):
        """处理整体作用查询（调用 LLM）"""
        yield event.plain_result("正在分析压缩包内容，请稍候...")

        # 收集关键文本文件
        content_parts = []
        total_size = 0

        # 优先读取的关键文件名
        priority_names = [
            "readme", "readme.md", "readme.txt", "readme.rst",
            "package.json", "composer.json", "cargo.toml", "go.mod",
            "pom.xml", "build.gradle", "requirements.txt", "pyproject.toml",
            "setup.py", "gemfile", "index.html", "main.py", "app.py",
            "main.js", "index.js", "app.js", "server.js",
            "dockerfile", "docker-compose.yml", "docker-compose.yaml",
            ".env.example", "config.json", "config.yaml", "config.yml",
            "makefile", "cmakelists.txt",
        ]

        def _read_key_file(fname: str) -> Optional[str]:
            nonlocal total_size
            fpath = os.path.join(session.extract_dir, fname)
            if not os.path.isfile(fpath):
                return None
            if not is_text_file(fname):
                return None
            content = safe_read_text(fpath, LLM_FILE_CONTENT_LIMIT)
            if content.startswith("["):
                return None
            size = len(content.encode("utf-8", errors="ignore"))
            if total_size + size > LLM_TOTAL_CONTENT_LIMIT:
                return None
            total_size += size
            return content

        # 先读优先文件
        for pname in priority_names:
            # 不区分大小写匹配
            for f in session.file_list:
                if Path(f.replace("\\", "/")).name.lower() == pname.lower():
                    content = _read_key_file(f)
                    if content:
                        content_parts.append(f"=== {f} ===\n{content}")
                    break

        # 再读其他文本文件（按层级深度排序，浅层优先）
        other_files = sorted(
            [f for f in session.file_list if is_text_file(f)],
            key=lambda x: x.count("/") + x.count("\\"),
        )
        for f in other_files:
            if total_size >= LLM_TOTAL_CONTENT_LIMIT:
                break
            # 跳过已读的优先文件
            if any(f"=== {f} ===" in p for p in content_parts):
                continue
            content = _read_key_file(f)
            if content:
                content_parts.append(f"=== {f} ===\n{content}")

        # 构建 prompt
        file_list_str = "\n".join(session.file_list[:200])
        if len(session.file_list) > 200:
            file_list_str += f"\n...（共 {len(session.file_list)} 个文件）"

        prompt = f"""以下是一个压缩包的文件列表和部分文件内容，请分析这个压缩包是什么、有什么作用。

压缩包文件名: {session.original_name}

文件列表:
{file_list_str}

部分文件内容:
{chr(10).join(content_parts[:30])}

请用中文简要说明：
1. 这个压缩包是什么（如：网页游戏源码、Python项目、配置文件包等）
2. 主要功能/用途
3. 技术栈（如果能识别）
4. 如何运行/使用（如果能从文件中判断）

请简洁明了，不要罗列文件。"""

        try:
            umo = event.unified_msg_origin
            provider_id = await self.context.get_current_chat_provider_id(umo=umo)
            if not provider_id:
                yield event.plain_result(
                    "当前会话未配置 AI 模型，无法分析压缩包作用。\n"
                    "你可以问我「结构」来查看文件目录。"
                )
                return
            llm_resp = await self.context.llm_generate(
                chat_provider_id=provider_id,
                prompt=prompt,
            )
            answer = llm_resp.completion_text or "（AI 未返回内容）"
            yield event.plain_result(f"压缩包分析结果：\n\n{answer}")
        except Exception as e:
            logger.exception(f"[ArchiveReader] LLM 分析失败: {e}")
            yield event.plain_result(f"AI 分析失败: {e}")

    async def _send_file_to_user(
        self, event: AstrMessageEvent, file_path: str, file_name: str
    ) -> bool:
        """发送文件给用户。
        优先使用 NapCat 的 upload_group_file/upload_private_file API（最可靠），
        回退到 AstrBot 标准 File 组件。
        注意：不要在同一条消息里混 Plain 文本，否则 AstrBot 适配器会把
        文本和文件拆成两条消息分别发送，导致"问一句回两句"。
        """
        abs_path = os.path.abspath(file_path)
        client = getattr(event, "bot", None)

        # 方式 1: NapCat / OneBot 上传文件 API
        if client is not None:
            try:
                async def _call_action(action: str, **kwargs):
                    if hasattr(client, "call_action"):
                        return await client.call_action(action, **kwargs)
                    if hasattr(client, "api") and hasattr(client.api, "call_action"):
                        return await client.api.call_action(action, **kwargs)
                    return None

                is_group = event.get_group_id()
                if is_group:
                    ret = await _call_action(
                        "upload_group_file",
                        group_id=int(is_group),
                        file=abs_path,
                        name=file_name,
                    )
                else:
                    ret = await _call_action(
                        "upload_private_file",
                        user_id=int(event.get_sender_id()),
                        file=abs_path,
                        name=file_name,
                    )

                if ret and (ret.get("retcode", -1) == 0 or ret.get("status") == "ok"):
                    logger.info(f"[ArchiveReader] 文件已通过 NapCat API 发送: {file_name}")
                    return True
                if ret:
                    logger.warning(f"[ArchiveReader] NapCat 上传返回异常: {ret}")
            except Exception as e:
                logger.warning(f"[ArchiveReader] NapCat upload API 失败，尝试回退方案: {e}")

        # 方式 2: AstrBot 标准 File 组件（只发文件，不带文本，避免拆条）
        try:
            await event.send(
                event.chain_result([Comp.File(file=abs_path, name=file_name)])
            )
            logger.info(f"[ArchiveReader] 文件已通过标准组件发送: {file_name}")
            return True
        except Exception as e:
            logger.error(f"[ArchiveReader] 标准 File 组件发送也失败: {e}")
            return False

    async def _handle_file_content(self, event: AstrMessageEvent, session: ArchiveSession, target: str):
        """处理文件原文查询"""
        matched = self._find_file_in_archive(session, target)
        if not matched:
            # 列出可能的文件
            suggestions = [
                f for f in session.file_list
                if Path(f).name.lower().startswith(target[0].lower())
            ][:10]
            msg = f"在压缩包中未找到文件: {target}"
            if suggestions:
                msg += "\n\n你可能想找:\n" + "\n".join(suggestions)
            yield event.plain_result(msg)
            return

        fpath = os.path.join(session.extract_dir, matched)
        if not os.path.isfile(fpath):
            yield event.plain_result(f"文件不存在: {matched}")
            return

        # 检查是否为二进制文件
        if not is_text_file(matched):
            yield event.plain_result(
                f"文件 {matched} 可能是二进制文件（如 exe/图片/视频等），无法发送文本版本。"
            )
            return

        # 读取内容
        content = safe_read_text(fpath)
        if content.startswith("[无法识别") or content.startswith("[读取失败"):
            yield event.plain_result(f"文件 {matched}: {content}")
            return

        # 生成 txt 文件
        tmp_dir = os.path.join(self.data_dir, "output")
        os.makedirs(tmp_dir, exist_ok=True)
        safe_basename = re.sub(r'[^\w\-.]', '_', Path(matched).name)
        txt_name = f"{Path(safe_basename).stem}.txt"
        txt_path = os.path.join(tmp_dir, f"{int(time.time())}_{txt_name}")

        async with aiofiles.open(txt_path, "w", encoding="utf-8") as f:
            await f.write(f"原始文件: {matched}\n")
            await f.write(f"来源压缩包: {session.original_name}\n")
            await f.write("=" * 60 + "\n\n")
            await f.write(content)

        # 直接通过 NapCat API 发送文件（一条消息，不带标题文本）
        ok = await self._send_file_to_user(event, txt_path, txt_name)

        if not ok:
            # 回退：直接在聊天中发文本
            text_content = content
            if len(text_content) > 3500:
                text_content = text_content[:3500] + "\n...（内容过长，已截断）"
            yield event.plain_result(
                f"文件发送失败，以下是 {matched} 的内容：\n\n{text_content}"
            )

        # 清理临时文件
        try:
            os.remove(txt_path)
        except Exception:
            pass

    async def _handle_file_purpose(self, event: AstrMessageEvent, session: ArchiveSession, target: str):
        """处理单个文件作用查询（调用 LLM）"""
        matched = self._find_file_in_archive(session, target)
        if not matched:
            suggestions = [
                f for f in session.file_list
                if Path(f).name.lower().startswith(target[0].lower())
            ][:10]
            msg = f"在压缩包中未找到文件: {target}"
            if suggestions:
                msg += "\n\n你可能想找:\n" + "\n".join(suggestions)
            yield event.plain_result(msg)
            return

        fpath = os.path.join(session.extract_dir, matched)
        if not os.path.isfile(fpath):
            yield event.plain_result(f"文件不存在: {matched}")
            return

        if not is_text_file(matched):
            yield event.plain_result(
                f"文件 {matched} 是二进制文件，无法分析其内容。"
            )
            return

        content = safe_read_text(fpath, LLM_FILE_CONTENT_LIMIT)
        if content.startswith("["):
            yield event.plain_result(f"文件 {matched}: {content}")
            return

        prompt = f"""请分析以下文件的作用。

文件路径: {matched}
来源压缩包: {session.original_name}

文件内容:
{content}

请用中文简要说明这个文件的作用和功能。如果是代码文件，请说明它实现了什么。简洁回答。"""

        try:
            umo = event.unified_msg_origin
            provider_id = await self.context.get_current_chat_provider_id(umo=umo)
            if not provider_id:
                yield event.plain_result("当前会话未配置 AI 模型，无法分析文件作用。")
                return
            llm_resp = await self.context.llm_generate(
                chat_provider_id=provider_id,
                prompt=prompt,
            )
            answer = llm_resp.completion_text or "（AI 未返回内容）"
            yield event.plain_result(f"文件 {matched}：\n\n{answer}")
        except Exception as e:
            logger.exception(f"[ArchiveReader] LLM 分析失败: {e}")
            yield event.plain_result(f"AI 分析失败: {e}")

    # ------------------------------------------------------------------
    # 消息处理
    # ------------------------------------------------------------------

    @filter.event_message_type(filter.EventMessageType.ALL)
    async def on_message(self, event: AstrMessageEvent):
        """主消息处理"""
        # 清理过期会话
        self._cleanup_expired()

        text = event.message_str.strip()
        umo = event.unified_msg_origin
        is_group = bool(event.get_group_id())

        # 查找文件组件
        file_comp = self._find_file_component(event)

        # 情况 1：消息中包含压缩包文件
        if file_comp:
            file_name = file_comp.name or self._get_file_name_from_raw(event) or ""
            if is_archive(file_name):
                # 群聊中需要 @机器人 才处理
                if is_group and not event.is_at_or_wake_command:
                    return

                session = await self._process_archive(event, file_comp)
                if session:
                    if is_group:
                        # 群聊：检查是否同时有提问
                        intent, target = self._detect_intent(text)
                        if intent == "structure":
                            async for r in self._handle_structure(event, session):
                                yield r
                        elif intent == "purpose":
                            async for r in self._handle_purpose(event, session):
                                yield r
                        elif intent == "content" and target:
                            async for r in self._handle_file_content(event, session, target):
                                yield r
                        elif intent == "file_purpose" and target:
                            async for r in self._handle_file_purpose(event, session, target):
                                yield r
                        else:
                            yield event.plain_result(
                                f"已接收压缩包 {session.original_name}（{len(session.file_list)} 个文件）。\n"
                                "你可以问我：\n"
                                "• 结构 — 查看目录结构\n"
                                "• 作用 — 分析压缩包用途\n"
                                "• 文件名+原文 — 提取文件内容"
                            )
                    else:
                        # 私聊：回复收到
                        yield event.plain_result(
                            f"收到压缩包 {session.original_name}（{len(session.file_list)} 个文件）。\n"
                            "你可以问我：\n"
                            "• 结构 — 查看目录结构\n"
                            "• 作用 — 分析压缩包用途\n"
                            "• 文件名+原文 — 提取文件内容"
                        )
                event.stop_event()
                return
            else:
                # 非压缩包文件，不处理（让其他插件/LLM处理）
                return

        # 情况 2：没有文件，但可能是关于已有压缩包的提问
        session = self._get_session(umo)
        if not session:
            return  # 没有会话，不处理

        # 群聊中需要 @机器人
        if is_group and not event.is_at_or_wake_command:
            return

        # 识别意图
        intent, target = self._detect_intent(text)

        if intent == "structure":
            async for r in self._handle_structure(event, session):
                yield r
            event.stop_event()
        elif intent == "purpose":
            async for r in self._handle_purpose(event, session):
                yield r
            event.stop_event()
        elif intent == "content" and target:
            async for r in self._handle_file_content(event, session, target):
                yield r
            event.stop_event()
        elif intent == "file_purpose" and target:
            async for r in self._handle_file_purpose(event, session, target):
                yield r
            event.stop_event()
        else:
            # 意图不明确，但有活跃会话
            # 注入上下文给 LLM，让 LLM 自然回答
            return  # 让 on_llm_request 钩子处理

    # ------------------------------------------------------------------
    # LLM 请求钩子：注入压缩包上下文
    # ------------------------------------------------------------------

    @filter.on_llm_request()
    async def on_llm_request(self, event: AstrMessageEvent, req):
        """当 LLM 即将回复时，如果有活跃的压缩包会话，注入上下文"""
        umo = event.unified_msg_origin
        session = self.sessions.get(umo)
        if not session:
            return

        # 检查会话是否过期
        if time.time() - session.last_used > SESSION_EXPIRE:
            self.sessions.pop(umo, None)
            return

        # 群聊中需要 @机器人
        is_group = bool(event.get_group_id())
        if is_group and not event.is_at_or_wake_command:
            return

        # 注入压缩包上下文（临时，不写入对话历史）
        file_list_preview = "\n".join(session.file_list[:100])
        if len(session.file_list) > 100:
            file_list_preview += f"\n...（共 {len(session.file_list)} 个文件）"

        context_text = (
            f"<archive_context>\n"
            f"用户之前发送了一个压缩包: {session.original_name}，"
            f"已解压并保存在当前会话中。\n"
            f"压缩包包含 {len(session.file_list)} 个文件。\n"
            f"文件列表:\n{file_list_preview}\n\n"
            f"如果用户问的是关于这个压缩包的问题，请基于以上文件列表回答。"
            f"如果用户要求查看某个文件的具体内容，请提示用户说「文件名+原文」。"
            f"如果用户问的是其他问题，请忽略此上下文。\n"
            f"</archive_context>"
        )

        try:
            req.extra_user_content_parts.append(
                TextPart(text=context_text).mark_as_temp()
            )
        except Exception as e:
            logger.warning(f"[ArchiveReader] 注入 LLM 上下文失败: {e}")
